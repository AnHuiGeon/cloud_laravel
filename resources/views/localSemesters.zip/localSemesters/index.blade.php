@extends('layouts.app')

@section('content')
<div class='container'>
    <h1>후쿠오카 현지학기제</h1>
    <hr>
    <button id='button-write'>작성</button>

    <div id='ls-modal-container'></div>
    <hr>
    <div id='ls-container'>
        @forelse($datas as $key=>$data)
            @include('localSemesters.partial.localSemester', compact('data'))
        @empty
            <p>글이 없습니다.</p>
        @endforelse
    </div>
</div>
@stop

@section('style')
    <style>
        #ls-container {
            width: 100%;
        }
        .ls-box {
            display: inline-block;
            border: solid black 1px;
            width: 31%;
            text-align: center;
            margin: 1%;
        }
        .ls-image {
            border: solid black 1px;
            width: 100%;
            height: 20vh;
            color: green;
        }
        .create-div {
            border: solid black 1px;
            width: 50px;
            height: 50px;
        }
        #ls-modal-container {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgb(0,0,0); /* Fallback color */
            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
        }
        .ls-modal-content {
            background-color: #fefefe;
            margin: 15% auto; /* 15% from the top and centered */
            padding: 20px;
            border: 1px solid #888;
            width: 75%; /* Could be more or less, depending on screen size */    
        }
        .ls-modal-show {
            background-color: #fefefe;
            margin: 15% auto; /* 15% from the top and centered */
            padding: 20px;
            border: 1px solid #888;
            width: 75%; /* Could be more or less, depending on screen size */    
        }
        #ls-modal-title {
            width: 90%;
        }
        #ls-modal-name {
            width: 90%;
        }
        #ls-modal-content {
            width: 90%;
        }
        #button-save {
        }
    </style>
@stop

@section('script')
    <script>
        window.onload = () => {
        var ls_modal_container = document.getElementById('ls-modal-container');
        // 작성 버튼을 위한 modal
        var create_div = document.createElement('div');
        create_div.className = 'ls-modal-content';
        create_div.innerHTML = '<form action="{{ route('localSemesters.store') }}" id="ls-form" name="ls-form" method="post"><label for="ls-modal-title">제목</label>\
        <input type="text" id="ls-modal-title" name="title" placeholder="title" />\
        <br>\
        <label for="ls-modal-name">이름</label>\
        <input type="text" id="ls-modal-name" name="name" placeholder="name" />\
        <br>\
        <label for="ls-modal-content">내용</label>\
        <textarea name="content" id="ls-modal-content" placeholder="content" rows="8" ></textarea>\
        <br>\
        <input type="submit" value="save" id="button-save"/></form>';
        ls_modal_container.appendChild(create_div);

        // image를 띄우는 modal
        var show_div = document.createElement('div');
        show_div.className = 'ls-modal-show';
        show_div.innerHTML = '<div>제목 : </div>\
        <br>\
        <div>번호 : </div>\
        <br>\
        <div>작성자</div>\
        <br>\
        <div>사진</div>\
        <br>\
        <div>이야기</div>\
        <br>';
        ls_modal_container.appendChild(show_div);
        
        document.getElementById('button-write').addEventListener('click', () => {
            ls_modal_container.appendChild(create_div);
            ls_modal_container.style.display = 'block';
            try{
                ls_modal_container.removeChild(show_div);
            } catch(e){
                // console.log('이미 child는 제거됨')
            }
        })

        document.getElementById('button-save').addEventListener('click', () => {
            document.getElementById('ls-modal-title').value='';
            document.getElementById('ls-modal-name').value='';
            document.getElementById('ls-modal-content').value='';
            ls_modal_container.removeChild(create_div);
            ls_modal_container.style.display = 'none';
        })

        window.onclick = function(event) {
            if (event.target == ls_modal_container) {
                ls_modal_container.style.display = "none";
            }
        }

        document.querySelectorAll('.ls-box').forEach((box)=>{
            box.querySelector('.ls-image').addEventListener('click', (e) => {
                console.log(e.target.getAttribute('name'));
                // show_div.value= 이름:  e.target
                ls_modal_container.appendChild(show_div);
                ls_modal_container.style.display = 'block';
                try{
                    ls_modal_container.removeChild(create_div);
                } catch(e){
                    // console.log('이미 child는 제거됨');
                }
            })
        })

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
            }
        });
        $('.button-delete').on('click', function(e){
            var id = e.target.getAttribute('name');
            console.log('dataId: ' + id);

            if(confirm('글을 삭제합니다.')){
                $.ajax({
                    type: 'DELETE',
                    url: '/localSemesters/' + id,
                    async: false,
                    headers : { // Http header
                    "Content-Type" : "application/json",
                    "X-HTTP-Method-Override" : "POST"
                    },
                }).then(function(){
                    e.target.parentNode.parentNode.removeChild(e.target.parentNode);
                });
            }
        });
    }
    </script>
@stop