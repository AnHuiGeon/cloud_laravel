@extends('layout.app')
@section('content')
<div id='create-modal' class='modal'>
    <div class='modal-content'>
        <label for=""></label>
    </div>
</div>
@stop
@section('style')
@stop
@section('script')
@stop